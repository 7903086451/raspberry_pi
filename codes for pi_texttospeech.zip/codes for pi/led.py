import RPi.GPIO as GPIO

led_pin1=40
led_pin2=37

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(led_pin1,GPIO.OUT,initial=GPIO.LOW)
GPIO.setup(led_pin2,GPIO.OUT,initial=GPIO.LOW)

try:
    while True:
        GPIO.output(led_pin1,GPIO.HIGH)
        GPIO.output(led_pin2,GPIO.HIGH)

except KeyboardInterrupt:
    GPIO.cleanup()
        
