import pytesseract
from PIL import Image

# Path to the image file
image_path = 'C:\Users\nikhi\AppData\Local\Temp\a7ab7347-5ccd-4e95-a05a-9cf3af920163_OCR_raspberry_pi_hardware.zip.163\saved_img.jpg'

# Open the image
img = Image.open(image_path)

# Perform OCR on the image
text = pytesseract.image_to_string(img)

# Print the extracted text
print("Extracted Text:")
print(text)