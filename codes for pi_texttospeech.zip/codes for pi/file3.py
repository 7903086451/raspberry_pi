import cv2
import pytesseract
import pyttsx3
import os
import pygame

# Initialize the camera
camera = cv2.VideoCapture(0)

# Set up Tesseract OCR
pytesseract.pytesseract.tesseract_cmd = 'C:/Program Files/Tesseract-OCR/tesseract.exe'

# Initialize Pygame for audio playback
pygame.init()

# Initialize text-to-speech engine
engine = pyttsx3.init()

# Function to perform OCR and convert text to speech
def process_frame(frame):
    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Perform OCR on the grayscale frame
    text = pytesseract.image_to_string(gray)

    # Convert text to speech
    engine.say(text)
    engine.runAndWait()

# Main loop
while True:
    ret, frame = camera.read()

    # Check for key press
    key = cv2.waitKey(1) & 0xFF

    # Process captured frame when "z" key is pressed
    if key == ord('z'):
        process_frame(frame)

    # Display the frame
    cv2.imshow('Frame', frame)

    # Check for key press (press 'q' to quit)
    if key == ord('q'):
        break

# Release the camera and close OpenCV windows
camera.release()
cv2.destroyAllWindows()