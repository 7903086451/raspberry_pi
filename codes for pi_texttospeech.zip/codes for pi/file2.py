import cv2
import pytesseract
from gtts import gTTS
import os
import pygame

# Initialize the camera
camera = cv2.VideoCapture(0)

# Set up Tesseract OCR
pytesseract.pytesseract.tesseract_cmd = 'C:/Program Files/Tesseract-OCR/tesseract.exe'

# Initialize Pygame for audio playback
pygame.init()

# Initialize capture flag
capture_flag = False

# Function to perform OCR and convert text to speech
def process_frame(frame):
    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Perform OCR on the grayscale frame
    text = pytesseract.image_to_string(gray)

    # Convert text to speech
    tts = gTTS(text=text, lang='en')
    tts.save('output.mp3')

    # Play the generated speech using Pygame
    pygame.mixer.music.load('output.mp3')
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        pygame.time.Clock().tick(10)

# Main loop
while True:
    ret, frame = camera.read()

    # Check for key press
    key = cv2.waitKey(1) & 0xFF

    # Capture image when "z" key is pressed
    if key == ord('z'):
        capture_flag = True

    # Process captured frame if flag is set
    if capture_flag:
        process_frame(frame)
        capture_flag = False

    # Display the frame
    cv2.imshow('Frame', frame)

    # Check for key press (press 'q' to quit)
    if key == ord('q'):
        break

# Release the camera and close OpenCV windows
camera.release()
cv2.destroyAllWindows()